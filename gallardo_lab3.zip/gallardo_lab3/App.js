import React, { useState } from "react";
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet } from "react-native";

export default function App() {
  const [text, setText] = useState("");
  const [items, setItems] = useState([]);

  const addItem = () => {
    if (text.trim() === "") return; // ignore empty input
    setItems([...items, text]);
    setText("");
  };

  return (
    <View style={styles.container}>
      <View style={styles.secondContainer}>
        <Text style={styles.title}>YAHO</Text>

        <View style={styles.row}>
          <TextInput
            style={styles.input}
            placeholder="Enter Item"
            value={text}
            onChangeText={setText}
          />

          {/* ✅ Custom button here */}
          <TouchableOpacity style={styles.button} onPress={addItem} activeOpacity={0.7}>
            <Text style={styles.buttonText}>ADD</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={items}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.listItem}>
              <Text style={styles.listText}>{item}</Text>
            </View>
          )}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1,
    padding: 20,
    marginTop: 40,
    backgroundColor: "#E6F0FA"
  },
  secondContainer: {
    backgroundColor: "#E0FFFF",
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#cfd8dc",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  title: { 
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20
  },
  row: { 
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10
  },
  input: {
    textAlign: "center",
    flex: 1,
    borderWidth: 1,
    borderColor: "#888",
    borderRadius: 20,
    paddingHorizontal: 10,
    height: 40,
    marginRight: 8,
    backgroundColor: "#fff",
  },
  button: {
    backgroundColor: "#2196F3", // blue
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  listItem: {
    backgroundColor: "#B3E5FC",
    padding: 10,
    borderRadius: 20,
    marginVertical: 4,
  },
  listText: { fontSize: 16 },
});
